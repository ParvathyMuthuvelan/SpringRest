package com.training.springrestapi.SpringRest.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.training.springrestapi.SpringRest.model.Person;
import com.training.springrestapi.SpringRest.service.PersonService;

@RestController
public class PersonController {
	@Autowired
	PersonService personService;

	@GetMapping("/getAllPersons")
	//public ResponseEntity<List<Person>> getAllPersons() {
	public List<Person> getAllPersons() {
		List<Person> personList = personService.getAllPersons();

		//return new ResponseEntity<>(personList, HttpStatus.OK);
		return personList;
	}

	@PostMapping("/savePerson")
	public ResponseEntity<Object> savePerson(@RequestBody Person person) {
		// employee = employeeService.save(employee);
		Person p = personService.createPerson(person);
		if (p != null) {

			return new ResponseEntity<>("success", HttpStatus.CREATED);
		} else {

			return new ResponseEntity<>("Insertion failed", HttpStatus.BAD_REQUEST);
		}
	}
	@PutMapping("/updatePerson")
	public ResponseEntity<Object> updatePerson(@RequestBody Person person) {
		
		Person p = personService.editPerson(person);
		if (p != null) {

			return new ResponseEntity<>("Person details updated", HttpStatus.OK);
		} else {

			return new ResponseEntity<>("Update failed", HttpStatus.BAD_REQUEST);
		}
	}
	@DeleteMapping("/deletePerson/{id}")
	public ResponseEntity<Object> deletePerson(@PathVariable ("id") long id) {
		personService.deletePerson(id);
		return new ResponseEntity<>("Person deleted", HttpStatus.OK);
	}
}
