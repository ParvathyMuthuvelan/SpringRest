package com.training.service;

import java.util.List;
import java.util.Optional;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.training.bean.Employee;
import com.training.dao.EmployeeRepository;

@Service
public class EmployeeServiceImpl {
	@Autowired
	// EmployeeDao empDao;
	EmployeeRepository empRepository;

	@Transactional
	public List<Employee> fetchEmployees() {
		// List<Employee> empList=empDao.fetchEmployees();
		List<Employee> empList = empRepository.findAll();
		return empList;
	}

	@Transactional
	public Employee addEmployee(Employee emp) {
		// return empDao.addEmployee(emp);
		return empRepository.save(emp);

	}

	@Transactional
	public Employee getEmployee(int empId) {
		Employee emp = null;
		Optional<Employee> optional = empRepository.findById(empId);
		if (optional.isPresent())
			emp = optional.get();
		return emp;
	}

	@Transactional
	public void updateEmployee(Employee emp) {
		// empDao.updateEmployee(emp);
		empRepository.save(emp);

	}

	public void deleteEmployee(int empId) {
		// empDao.deleteEmployee(empId);
		empRepository.deleteById(empId);

	}

	public Employee findEmployee(int id) {
		Employee emp = null;
		// Employee emp=empDao.getEmployee(id);
		return emp;
	}

}
