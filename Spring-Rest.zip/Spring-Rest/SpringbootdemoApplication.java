package com.training.springboot.springbootdemo;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

@SpringBootApplication
@ComponentScan({"com"})
@EnableJpaRepositories(basePackages = "com.training.dao")
@EntityScan({ "com.training.bean" })
public class SpringbootdemoApplication {
	private static final Logger LOG = LoggerFactory.getLogger(SpringbootdemoApplication.class);
	public static void main(String[] args) {
		LOG.debug("Logger  initialized");
		SpringApplication.run(SpringbootdemoApplication.class, args);
	}

}
//Debug < Info < Warn < Error < Fatal. 