//client->request->(dispatcherservlet)->controller->service->dao
package com.training.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.training.bean.Employee;
import com.training.exception.InvalidIdException;
import com.training.service.EmployeeServiceImpl;

@RequestMapping("/api/v1/employees")
@RestController
public class EmployeeController {

	@Autowired
	EmployeeServiceImpl employeeService;

	@GetMapping("/getEmployees")
	public List<Employee> getEmployees() {
		List<Employee> empList = employeeService.fetchEmployees();

		return empList;

	}
//@ResponseStatus(value=HttpStatus.NOT_FOUND,reason="Invalid employee id")
	@GetMapping("/getEmployeeById/{id}")
	public ResponseEntity<Employee> getEmployee(@PathVariable("id") int id) {
		Employee emp = null;
		ResponseEntity<Employee> response = null;
		try {
			emp = employeeService.getEmployee(id);
			System.out.println("employee object="+emp);
			if (emp == null) {
				throw new InvalidIdException("");
			}
			response = new ResponseEntity<Employee>(emp, HttpStatus.OK);
		} catch (InvalidIdException e) {
			System.out.println("catch block");
			response = new ResponseEntity<Employee>(emp, HttpStatus.NOT_FOUND);
		}
		return response;
	}

	@PostMapping("/addEmployee")
	public ResponseEntity<Object> addEmployee(@RequestBody Employee emp) {

		Employee employee = employeeService.addEmployee(emp);

		return new ResponseEntity<>("Employee added successsfully", HttpStatus.OK);
	}

	@PutMapping(value = "/updateEmployee")
	public ResponseEntity<Object> updateEmployee(@RequestBody Employee emp) {

		employeeService.updateEmployee(emp);

		return new ResponseEntity<>("Employee updated successsfully", HttpStatus.OK);
	}

///deleteEmployee/1
	@DeleteMapping(value = "/deleteEmployee/{employeeId}")
	public ResponseEntity<Object> deleteEmployee(@PathVariable("employeeId") Integer empId) throws InvalidIdException {
		employeeService.deleteEmployee(empId);
		return new ResponseEntity<>("Employee deleted successsfully", HttpStatus.OK);
	}

}
