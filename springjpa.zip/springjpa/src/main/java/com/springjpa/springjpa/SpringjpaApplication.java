package com.springjpa.springjpa;

import java.sql.Date;
import java.util.List;
import java.util.Set;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

import com.springjpa.model.Department;
import com.springjpa.model.Employee;
import com.springjpa.model.Person;
import com.springjpa.model.Skill;
import com.springjpa.service.DepartmentService;
import com.springjpa.service.EmployeeService;
import com.springjpa.service.PersonService;
import com.springjpa.service.SkillService;

@SpringBootApplication
@ComponentScan({ "com*" })
@EnableJpaRepositories(basePackages = "com.springjpa.dao")
@EntityScan({ "com.springjpa.model" })
public class SpringjpaApplication // implements CommandLineRunner
{
	private static final Logger LOGGER = LoggerFactory.getLogger("JCG");

	@Autowired
	private static PersonService personService;
	@Autowired
	public static EmployeeService employeeService;
	@Autowired
	public static DepartmentService departmentService;
	@Autowired
	public static SkillService skillService;

	public static void testGetEmployee() {
		LOGGER.info("Start");
		Employee employee = employeeService.get(4);
		System.out.println("Employee ="+employee);
		System.out.println("Department ="+employee.getDepartment());
	//	System.out.println("Skill ");
	//	Set<Skill> skillList=employee.getSkillList();
	//	skillList.forEach(obj->System.out.println(obj));
		//LOGGER.debug("Employee:{}", employee);
		//LOGGER.debug("Department:{}", employee.getDepartment());
		//LOGGER.debug("Skills:{}", employee.getSkillList());
		LOGGER.info("End");
	}

	public static void testAddEmployee() {
		LOGGER.info("Start");
		Employee employee = new Employee();
		employee.setName("Abc");
		employee.setSalary(30000);
		employee.setPermanent(true);
		employee.setDate_of_birth(Date.valueOf("1995-02-21"));
		Department department = departmentService.get(2);
		employee.setDepartment(department);
		employeeService.save(employee);
		LOGGER.debug("Employee:{}", employee);
		LOGGER.info("End");
	}

	public static void testUpdateEmployee() {
		LOGGER.info("Start");
		Employee employee = employeeService.get(2);
		Department department = departmentService.get(1);
		employee.setDepartment(department);
		employeeService.save(employee);
		LOGGER.debug("Employee:{}", employee);
		LOGGER.info("End");
	}

	public static void testGetDepartment() {
		LOGGER.info("Start");
		Department department = departmentService.get(1);
		LOGGER.debug("Department:{}", department);
		Set<Employee> employees = department.getEmployeeList();
		LOGGER.debug("Employee List:{}", employees);
		LOGGER.info("End");
	}

	public static void testAddSkillToEmployee() {
		LOGGER.info("Start");
		Employee employee = employeeService.get(4);
		Skill skill = skillService.get(2);
		employee.getSkillList().add(skill);
		employeeService.save(employee);
		LOGGER.info("End");
	}
	public static void testAddPerson() {
		LOGGER.info("Start");
	Person p=new Person();
	p.setAge(23);
	p.setId(100L);
	p.setName("abc");
	personService.createPerson(p);
	
		LOGGER.info("End");
	}
	public static void main(String[] args) {

		// SpringApplication.run(SpringjpaApplication.class, args);
		ApplicationContext context = SpringApplication.run(SpringjpaApplication.class, args);
		 personService = context.getBean(PersonService.class);
		 testAddPerson();
		List<Person> personList=personService.getAllPersons();
		for(Person p:personList) {
			  System.out.println(p);
		}
		personService.updatePersonAge(33,16L);
		LOGGER.info("After update ");
		personList=personService.getAllPersonsSorted(); 
		for(Person p:personList) {
			  System.out.println(p);
		}
		
//		employeeService = context.getBean(EmployeeService.class);
//		departmentService = context.getBean(DepartmentService.class);
//		skillService = context.getBean(SkillService.class);
		//testGetEmployee();
		//testAddEmployee();
		//testUpdateEmployee();
		//testGetDepartment();
		//testAddSkillToEmployee();

		/*
		 * personService = context.getBean(PersonService.class); Person person =
		 * personService.createPerson(new Person("Shubham", 23));
		 * person=personService.createPerson(new Person("Sai", 35)); long
		 * count=personService.countPersons(); 
		 * LOG.info("No of rows in DB: {}", count);
		 * List<Person> personList=personService.getAllPersons(); for(Person
		 * obj:personList) { System.out.println(obj); }
		 * System.out.println("Search with id "); Person
		 * obj=personService.getPersonById(16); System.out.println(obj);
		 * personList=personService.getAllPersonsSorted(); for(Person p:personList) {
		 * System.out.println(p); }
		 */
	}
}
